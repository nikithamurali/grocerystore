from appJar import gui #uncomment this for 100% submission


#Sample Team Project Extra Credit -- Shopping Application 110%
#Make sure to include the files for your team csv and .gif in your submission!
#include the app.Jar folder in the folder where your team files are stored

#Function to greet the user and ask for a category #draft 1 by Cliff

import pandas
import tkinter #uncomment this for 100% submission
cart = ""
total = 0
item = 0
tdf=pandas.read_csv("Grocery.csv")
fruitlist = list(tdf.Fruit)
bakerylist = list(tdf.Bakery)
beveragelist = list(tdf.Beverage)
def greet_user(greeting,sentinel,categoryq,readyq):
    canswer = ' '
    ranswer = sentinel
    print(greeting)
    while ranswer == sentinel:
        canswer = input(categoryq)
        ranswer = input(readyq)
    if canswer == "Fruit":
        fruit("Welcome to our Fruits section! Here are your choices:",fruitlist,"Which Fruit would you like or enter None? ")
    elif canswer == "Bakery":
        bakery("Welcome to our Bakery section!  Here are your choices:",bakerylist,"Which Bakery would you like or enter None? ")
    elif canswer == "Beverage":
        beverage("Welcome to our Beverage section! Here are your choices:",beveragelist,"Which Beverage would you like or enter None? ")
    else:
        print('Sorry, we do not carry that category.  Thank you come again!')


#Function to ask user to pick a Fruit
def fruit(greeting,selection,pickq):
    print(greeting)
    for item in selection:
        print(item)
    fruitpick = input(pickq)
    if fruitpick == "None":
        print("Goodbye")
    elif fruitpick == "Apples":
        closing("Apple",5,"Enjoy your Apple!" )
    elif fruitpick == "Orange":
        closing("Orange",4,"Enjoy your Orange!" )
    elif fruitpick == "Bananas":
        closing("Bananas",3,"Enjoy your Banana!" )
    elif fruitpick == "Mango":
        closing("Mango",7,"Enjoy your Mango!" )
    else:
        closing("Kiwi",6,"Enjoy your Kiwi!" )
    

#Function to ask user to pick a Bakery
def bakery(greeting,selection,pickq):
    print(greeting)
    for item in selection:
        print(item)
    bakerypick = input(pickq)
    if bakerypick == "None":
        print("Goodbye")
    elif bakerypick == "Bread":
        closing("Bread",5,"Enjoy your Bread!" )
    elif bakerypick == "Donuts":
        closing("Donuts",4,"Enjoy your Donuts!" )
    elif bakerypick == "Cookies":
        closing("Cookies",2,"Enjoy your Cookies!" )
    elif bakerypick == "Muffins":
        closing("Muffins",8,"Enjoy your Muffins!" )
    else:
        closing("Danish",10,"Enjoy your Danish" )
        
#Function to ask user to pick a Beverage
def beverage(greeting,selection,pickq):
    print(greeting)
    for item in selection:
        print(item)
    beveragepick = input(pickq)
    if beveragepick == "None":
        print("Goodbye")
    elif beveragepick == "Water":
        closing("Water",4,"Enjoy your Water!")
    elif beveragepick == "Apple Juice":
        closing("Apple Juice",5,"Enjoy your Apple Juice!")
    elif beveragepick == "Soda":
        closing("Soda",10,"Enjoy your Soda!")
    elif beveragepick == "Orange Juice":
        closing("Orange Juice",7,"Enjoy your Orange Juice!")
    else:
        closing("Mango Juice",9,"Enjoy your Mango Juice!")
        
#Function to give user total price of purchase
def closing(pickeditem,price,goodbye):
    global cart
    global total
    global item
    item = item + 1
    cart = cart + " " + pickeditem
    total = total + price
    ttotal = total*1.09
    print("Your",item,"item(s) so far:",cart)
    print("Your cost for the",pickeditem,"is $%.2f."%price)
    print("Your total cost is $%.2f."%total,"for",item,"item(s)")
    print("Your total cost plus tax is $%.2f."%ttotal,"for",item,"item(s)")
    more = input("Would you like to pick another item (y/n)?")
    if more == "y":
        greet_user("Great!", "n", "What category would you like to browse (Fruit, Bakery, Beverage)? ", "Ready to browse (y/n)? ")
    else:
        print("Please pay $%.2f!"%ttotal,"for your",item,"item(s)")
        print("Your shopping cart items:")
        for l in cart:
            print(l,end="")
        print()
        print("Thank you for shopping at GroceryMart!")


    
#make the code on line 119 a comment (use #) for 100% submission
        
#greet_user("Welcome to our store", "n", "What category would you like to browse (Fruit, Bakery, Beverage)? ", "Ready to browse (y/n)? ")





#Uncomment this section for 100% submission (remove the three quote marks from lines 123 and 183) #Nikitha worked on this part
#This is the function that determines code executed when each button is pressed

#Each teammember should replace the Button name assigned to btn (see line 91 for an example) 
#in the if-elif statements below with
#a short title for his/her function.  Then place a call to the
#corresponding function on the next line



def press(btn):
    if btn == "Exit":
        app.stop()
    elif btn == "Hello":
        greet_user("Welcome to our store", "n", "What category would you like to browse (Fruit, Bakery, Beverage)? ", "Ready to browse (y/n)? ")
    elif btn == "Fruit":
        fruit("Welcome to our Fruits section! Here are your choices:",fruitlist,"Which Fruit would you like or enter None? ")
    elif btn == "Bakery":
         bakery("Welcome to our Bakery section!  Here are your choices:",bakerylist,"Which Bakery item would you like or enter None? ")    
    elif btn == "Beverage":
         beverage("Welcome to our Beverage section! Here are your choices:",beveragelist,"Which Beverage would you like or enter None? ")   
    elif btn == "Close":
        app.infoBox("b1","Thank you for shopping!")   
    else:
        print('Pick a valid option')


#The code below defines the gui, adding buttons, labels, images, color, etc. #David worked on this part, and edited the previous code.
#
#Make changes to the title (line 163), image (line 169), and button
#names (lines 175 to 180)

#Edit 500x500 in line 159 to make your window bigger or smaller

app=gui("Main Menu","1600x1200")

#Replace "Welcome to Our Store's Main Menu" with your team's greeting in line 117

app.addLabel("title", "Welcome to GroceryMart Menu")
app.setLabelBg("title", "orange")

#Find your team gif image, save to your project code folder, and replace k.gif
#with the image file name in line 166

app.addImage("decor","GroceryMart.gif")
app.setFont(18)

#change the first parameter of the addButton method in lines 172 to 177 with names aligning with your team functions
#make sure they match the Button names in the press function above

app.addButton("Hello", press)
app.addButton("Fruit", press)
app.addButton("Bakery", press)
app.addButton("Beverage", press)
app.addButton("Close", press)
app.addButton("Exit",press)
app.go() #displays the gui

